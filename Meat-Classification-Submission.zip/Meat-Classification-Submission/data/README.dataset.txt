Meat Freshness - v1 New Dataset
==============================

It includes 2266 images.
Color-Marbling-Freshness are annotated in Multi-Class Classification format.

CLASSES
Fresh, Half-Fresh, Spoiled

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.